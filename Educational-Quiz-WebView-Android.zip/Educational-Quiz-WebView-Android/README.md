# Educational Quiz App (HTML wrapped in Android WebView)

The existing quiz HTML is bundled at `app/src/main/assets/index.html` and opens offline in Android WebView.

## Build on GitHub Actions
1. Upload the contents of this project folder to the root of a GitHub repository (not the ZIP file itself).
2. Open the repository's Actions tab and enable Actions if prompted.
3. Select `Build Educational Quiz APK` and tap `Run workflow`, or push a commit to `main`/`master`.
4. Open the completed workflow run, scroll to Artifacts, and download `Educational-Quiz-App-APK`.
5. Extract the artifact ZIP to get `app-debug.apk`, then open it on your Android phone to install.

This is a debug APK for personal testing. For public distribution, create a signed release build.
